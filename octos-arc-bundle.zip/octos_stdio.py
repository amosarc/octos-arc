"""Minimal Octos UI Protocol v1 stdio driver (mirrors octos-tui).

Spawns `octos serve --stdio --solo` and speaks NDJSON JSON-RPC over
stdin/stdout. No handshake: send session/open, then turn/start, then collect
notifications until turn/completed or turn/error. Approvals are auto-approved
so the agent never blocks unattended.
"""

from __future__ import annotations

import json
import os
import queue
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Callable, Iterator


class OctosProtocolError(RuntimeError):
    pass


# turn/start media 通道的图片类型白名单(与内核 vision.rs 的扩展名→MIME
# 映射同口径;非白名单文件在组装期静默跳过,不发坏帧)。
_IMAGE_MIME = {".png": "image/png", ".jpg": "image/jpeg",
               ".jpeg": "image/jpeg", ".gif": "image/gif",
               ".webp": "image/webp"}


def image_file_refs(paths) -> list[dict]:
    """本地图片文件 → turn/start `media` FileRef 列表。

    FileRef 形状由内核 TurnStartParams.media 钉死(crates/octos-core/
    src/ui_protocol.rs:1160:path/mime/size_bytes);path 用绝对路径
    (内核对图片透传不落 uploads/)。缺失文件与非图片后缀静默跳过——
    调用方(视觉核验轮)对"一张都没取到"自行降级,这里不做策略。"""
    out: list[dict] = []
    for p in paths:
        path = Path(p)
        mime = _IMAGE_MIME.get(path.suffix.lower())
        if mime is None:
            continue
        try:
            size = path.stat().st_size
        except OSError:
            continue
        out.append({"path": str(path.resolve()), "mime": mime,
                    "size_bytes": size})
    return out


def build_turn_start_params(session_id: str, turn_id: str, text: str,
                            media: list[dict] | None = None) -> dict:
    """turn/start payload(纯函数,钉媒体通道的线上形状)。

    media 缺省时与历史 payload 逐字节一致;带图时序列化为
    `media: [...]`,内核把 User 消息图片 base64 内联进请求(带图请求
    由 VISUAL_MODEL 路由切视觉模型)。"""
    params: dict = {
        "session_id": session_id,
        "turn_id": turn_id,
        "input": [{"kind": "text", "text": text}],
    }
    if media:
        params["media"] = list(media)
    return params


class OctosStdioSession:
    def __init__(self, octos_bin: str, cwd: Path, env: dict, data_dir: Path,
                 on_event: Callable[[str, dict], None] | None = None,
                 system_context: str | None = None,
                 hydrate_timeout: float = 30.0) -> None:
        self.cwd = str(cwd)
        self.data_dir = Path(data_dir)
        # 分层装配的全局层(root 契约+标题树+契约):create 后/upsert 前
        # 落盘到 per-profile data 目录(见 _inject_system_context)。
        self.system_context = system_context
        self.on_event = on_event or (lambda method, params: None)
        cmd = [octos_bin, "serve", "--stdio", "--solo", "--data-dir", str(data_dir)]
        if env.get("OCTOS_DANGER_FULL_ACCESS") == "1":
            cmd.append("--danger-full-access")
        self.proc = subprocess.Popen(
            cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, cwd=self.cwd, env=env,
            errors="replace", bufsize=1,
        )
        self._pending: dict[str, queue.Queue] = {}
        self._pending_lock = threading.Lock()
        self._notifications: queue.Queue = queue.Queue()
        self._stderr_lines: list[str] = []
        self._id_counter = 0
        # 会话最后一条非空 assistant 行(session/hydrate 取回)。内核治理
        # 中止(doom 等)以 Ok+合成收尾行送达,该行不在 message/delta 流里
        # ——turn/completed 后从持久化会话取回,宿主据此识别"内核代收尾"。
        self.last_final_assistant: str | None = None
        self.hydrate_timeout = hydrate_timeout
        self._reader = threading.Thread(target=self._read_stdout, daemon=True)
        self._reader.start()
        self._stderr_reader = threading.Thread(target=self._read_stderr, daemon=True)
        self._stderr_reader.start()
        self.session_id = f"arc-bundle:{uuid.uuid4().hex[:8]}"

    # ------------------------------------------------------------ plumbing

    def _read_stderr(self) -> None:
        assert self.proc.stderr is not None
        for line in self.proc.stderr:
            line = line.rstrip()
            self._stderr_lines.append(line)
            if "[arc-mod]" in line:
                # Patched-core proof marker (examples/core-mod): forward it so
                # the driver can log it into the graded stdout/stderr capture.
                self.on_event("core/marker", {"line": line})

    def _read_stdout(self) -> None:
        assert self.proc.stdout is not None
        for line in self.proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                frame = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "method" in frame:
                self._notifications.put(frame)
            elif "id" in frame:
                with self._pending_lock:
                    q = self._pending.pop(str(frame["id"]), None)
                if q is not None:
                    q.put(frame)

    def _send(self, method: str, params: dict | None, want_response: bool,
              timeout: float = 60.0) -> dict | None:
        self._id_counter += 1
        rid = f"py-{self._id_counter}"
        msg: dict = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            msg["params"] = params
        q: queue.Queue | None = None
        if want_response:
            msg["id"] = rid
            q = queue.Queue()
            with self._pending_lock:
                self._pending[rid] = q
        assert self.proc.stdin is not None
        try:
            self.proc.stdin.write(json.dumps(msg, ensure_ascii=False) + "\n")
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError) as exc:
            raise OctosProtocolError(
                f"octos stdio write failed (process died?): {exc}; "
                f"stderr tail: {self.stderr_tail()}") from exc
        if q is None:
            return None
        try:
            frame = q.get(timeout=timeout)
        except queue.Empty as exc:
            raise OctosProtocolError(f"timeout waiting response to {method}") from exc
        if "error" in frame:
            raise OctosProtocolError(f"{method} failed: {frame['error']}")
        return frame.get("result")

    def stderr_tail(self, n: int = 10) -> str:
        return "\n".join(self._stderr_lines[-n:])

    def _last_assistant_content(self) -> str | None:
        """turn 结束后取回会话最后一条非空 assistant 行(尽力而为)。

        走 session/hydrate(include=["messages"])而非 delta 流:内核
        治理中止的合成收尾行只持久化、不进 delta。任何失败都降级为
        None 并把原因留在 stderr——取回失败=宿主按现状分类,绝不抛。
        """
        try:
            res = self._send("session/hydrate", {
                "session_id": self.session_id,
                "include": ["messages"],
            }, want_response=True, timeout=self.hydrate_timeout)
            for row in reversed((res or {}).get("messages") or []):
                content = str(row.get("content") or "")
                if row.get("role") == "assistant" and content.strip():
                    return content
        except (OctosProtocolError, AttributeError, KeyError,
                TypeError, ValueError) as exc:
            self._stderr_lines.append(
                f"[stdio] final-assistant hydrate failed ({exc}); "
                "kernel-terminal detection degraded")
        return None

    # ------------------------------------------------------------ protocol

    def bootstrap_profile(self, provider: str, model: str, base_url: str | None,
                          api_key_env: str | None, timeout: float = 60.0) -> None:
        """Create a solo profile and select its LLM (serve mode has no config-
        file default profile like `octos chat` does, so we onboard one).

        The requested id must be unique per call: the runner machine's
        profile store persists across submissions and across our own retry
        re-bootstraps, so a fixed id collides with earlier runs
        ("local profile 'arc-2' already exists with different email")."""
        import os
        unique = f"arc-{os.getpid()}-{int(time.time() * 1000) % 10_000_000}"
        res = self._send("profile/local/create", {
            "requested_id": unique,
            "name": "ARC Bundle Agent",
            # legacy fields required by older releases (<= v2.0.1)
            "username": unique,
            "email": f"{unique}@solo.local",
        }, want_response=True, timeout=timeout)
        self.profile_id = res.get("profile_id") if isinstance(res, dict) else None
        if not self.profile_id:
            raise OctosProtocolError(f"profile/local/create gave no profile_id: {res}")
        self._inject_turn_limits()
        self._inject_system_context()
        api_type = "anthropic" if provider == "anthropic" else "openai"
        route: dict = {"api_type": api_type}
        if base_url:
            route["base_url"] = base_url
        if api_key_env:
            route["api_key_env"] = api_key_env
        self._send("profile/llm/upsert", {
            "profile_id": self.profile_id,
            "set_primary": True,
            "selection": {
                "family_id": provider,
                "model_id": model,
                "route": route,
            },
        }, want_response=True, timeout=timeout)

    def _inject_system_context(self) -> None:
        """把字节稳定的全局层落盘到 per-profile data 目录的 AGENTS.md。

        内核 serve 路径的系统行装配链(实读核实):serve.rs:344 传
        profile_data_dir=resolve_data_dir(profile)=<data_dir>/profiles/
        <pid>/data → profile.rs:582 build_system_prompt 双实参同源 →
        load_bootstrap_files(commands/mod.rs:149)读该目录下 AGENTS.md
        进系统行(base+date 之后、memory 之前,无 cap)。

        时序同 _inject_turn_limits:create 之后、llm/upsert 之前——
        upsert 触发 ProfileRuntime 重建,重读盘上 bootstrap 文件;每分段
        新会话(new profile id)重新注入,内容字节稳定即跨段缓存前缀一致。
        """
        if not self.system_context:
            return
        data_dir = (self.data_dir / "profiles" / str(self.profile_id)
                    / "data")
        data_dir.mkdir(parents=True, exist_ok=True)
        path = data_dir / "AGENTS.md"
        path.write_text(self.system_context, encoding="utf-8")
        self._stderr_lines.append(
            f"[stdio] system-row context injected: {path} "
            f"({len(self.system_context)} chars)")

    def _inject_turn_limits(self) -> None:
        """Bound every turn of this session: iteration cap + output cap.

        serve 的 OUP 回合按 Interactive 意图归类: profile 没有显式
        gateway.max_iterations 时内核不设回合上限 (自治通道的 50 次兜底
        只覆盖非 OUP lane), 实测单节点 turn 冲到 114-136 次迭代 /
        872K 累计 token (2026-09-21 keep 模拟 run1/run2)。显式 profile
        上限对 Interactive 同样生效 (turn_policy), 所以直接落盘改写
        注册表 JSON。默认 100 = 失控尾部保险丝, 不误伤自然收敛。

        单次响应输出上限同通道注入 (gateway.max_output_tokens): serve
        的 profile 会话默认吃内核内置 16K/响应 (octos-llm context.rs
        default_max_tokens), 2026-10-02 github 跑实测调试独白单响应
        16384 tok 撞顶被截 (turn/error output_truncated, 零工具调用)。
        默认 131072 (deepseek-v4 native completion 384K, catalog 值),
        env OCTOS_MAX_OUTPUT_TOKENS 覆盖, "0"=留在内核默认。

        时序必须在 create 之后、llm/upsert 之前: upsert 是"从磁盘读
        profile → 合并 LLM 选择 → save_with_merge → 代数守护重建运行时"
        (#2164), 编辑搭这班车进入重建后的运行时; upsert 之后再改会被
        已缓存的运行时遮蔽。
        """
        raw_iter = os.environ.get("OCTOS_TURN_MAX_ITERATIONS", "").strip() or "100"
        try:
            iter_cap = int(raw_iter)
        except ValueError:
            iter_cap = 100
        raw_out = os.environ.get("OCTOS_MAX_OUTPUT_TOKENS", "").strip() or "131072"
        try:
            out_cap = int(raw_out)
        except ValueError:
            out_cap = 131072
        registry = self.data_dir / "profiles" / f"{self.profile_id}.json"
        notes = []
        try:
            profile = json.loads(registry.read_text(encoding="utf-8"))
            gateway = profile.setdefault("config", {}).setdefault("gateway", {})
            changed = False
            if iter_cap > 0:
                if gateway.get("max_iterations") in (None, iter_cap):
                    gateway["max_iterations"] = iter_cap
                    changed = True
                    notes.append(f"iterations={iter_cap}")
            else:
                notes.append(f"iterations uncapped (OCTOS_TURN_MAX_ITERATIONS={raw_iter})")
            if out_cap > 0:
                if gateway.get("max_output_tokens") in (None, out_cap):
                    gateway["max_output_tokens"] = out_cap
                    changed = True
                    notes.append(f"max_output_tokens={out_cap}")
            else:
                notes.append(
                    "max_output_tokens left at kernel default "
                    f"(OCTOS_MAX_OUTPUT_TOKENS={raw_out})")
            if changed:
                tmp = registry.with_suffix(".json.tmp")
                tmp.write_text(json.dumps(profile, ensure_ascii=False, indent=2),
                               encoding="utf-8")
                os.replace(tmp, registry)
        except (OSError, ValueError) as exc:
            # 注册表布局漂移或 IO 失败: 不让整个提交挂掉, 退化为内核默认
            # (与旧行为一致), 但把原因留在 stderr 里。
            self._stderr_lines.append(
                f"[stdio] turn-limit injection skipped ({exc})")
            return
        self._stderr_lines.append(
            f"[stdio] turn limits injected: {'; '.join(notes)} "
            f"({registry.name})")

    def open(self, timeout: float = 120.0) -> None:
        params = {"session_id": self.session_id, "cwd": self.cwd}
        if getattr(self, "profile_id", None):
            params["profile_id"] = self.profile_id
        self._send("session/open", params, want_response=True, timeout=timeout)

    def run_turn(self, text: str, timeout: float = 1800.0,
                 wall_timeout: float | None = None,
                 media: list[dict] | None = None) -> tuple[bool, str]:
        """Run one turn; stream events to on_event. Returns (ok, full_text).

        `timeout` is an IDLE budget, not a wall clock: the deadline resets
        on every protocol event (deltas, tool traffic), so a slow but
        progressing turn is never killed mid-write. The 2026-09-16
        ticket-booking baseline lost a 1200s wall-clock turn that was
        actively streaming (slow provider: 30-60s TTFB, 0.3-15 tok/s),
        leaving server.js truncated mid-declaration.

        `wall_timeout`, when given, IS a hard wall clock for the whole
        turn: the host uses it to enforce per-node budget shares. Without
        it the wall defaults to 3x the idle budget (min 1h) — which let a
        single 2667s reasoning-heavy turn starve four sibling nodes on
        2026-09-20.

        `media`, when given, is a list of FileRef dicts (see
        image_file_refs) attached to the turn's User message — the only
        channel the kernel inlines into the LLM request (tool results
        cannot carry images). Image-bearing requests are routed to the
        VISUAL_MODEL by the kernel when one is configured.
        """
        turn_id = str(uuid.uuid4())
        self._send("turn/start", build_turn_start_params(
            self.session_id, turn_id, text, media),
            want_response=True, timeout=60.0)

        chunks: list[str] = []
        hard_deadline = time.monotonic() + (
            wall_timeout if wall_timeout is not None
            else max(timeout * 3, 3600.0))
        idle_deadline = time.monotonic() + timeout
        while True:
            now = time.monotonic()
            if now >= hard_deadline:
                return False, "octos turn hard wall clock exceeded"
            if now >= idle_deadline:
                return False, "octos turn idle timeout (no protocol events)"
            if self.proc.poll() is not None:
                return False, (f"octos process exited {self.proc.returncode}; "
                               f"stderr tail: {self.stderr_tail()}")
            try:
                # Cap the wait at 5s so a killed/exited process is noticed
                # within one poll even when the idle deadline is far away
                # (the stdout reader exits on EOF without a sentinel).
                frame = self._notifications.get(
                    timeout=min(max(min(idle_deadline, hard_deadline) - now,
                                    0.05), 5.0))
            except queue.Empty:
                continue
            method = frame.get("method", "")
            params = frame.get("params") or {}
            self.on_event(method, params)
            if method == "server/heartbeat":
                continue
            idle_deadline = time.monotonic() + timeout
            if method == "message/delta" and params.get("turn_id") == turn_id:
                chunks.append(str(params.get("text", "")))
            elif method == "approval/requested":
                # Auto-approve so unattended runs never block.
                try:
                    self._send("approval/respond", {
                        "approval_id": params.get("approval_id"),
                        "decision": "approve",
                        "approval_scope": "request",
                    }, want_response=True, timeout=30.0)
                except OctosProtocolError:
                    pass
            elif method == "turn/completed" and params.get("turn_id") == turn_id:
                self.last_final_assistant = self._last_assistant_content()
                return True, "".join(chunks)
            elif method == "turn/error" and params.get("turn_id") == turn_id:
                return False, (f"{params.get('code', 'error')}: "
                               f"{params.get('message', '')}"[:1000])

    def close(self) -> None:
        try:
            self.proc.terminate()
            self.proc.wait(timeout=10)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass

    def __enter__(self) -> "OctosStdioSession":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
