# frontend/src/features — feature implementation notes

Each requirement domain lives in its own self-contained file here
(<name>.jsx, default export). This README is HOST-OWNED (read-only).
The host PRE-CREATES one stub per requirement family at initialization
(headers list the family's REQ ids as a work order); fill them in place
and add sibling files freely — the division is a starting grid, not a cage.

## Grid editor kernel pattern (spreadsheet-like tasks)

Build every grid feature on ONE shared selection+editing state model,
created in the FIRST grid feature file and imported by later features
(never re-implemented, never rewritten):

```jsx
// useGrid: single source of truth for selection + editing
// anchor + focus cells define the rectangular selection
const [grid, setGrid] = useState({
  anchor: 'A1', focus: 'A1', editing: null, // editing: {coord, draft}
});
// aria contract (graded): each cell renders
//   role="gridcell" aria-label={coord}
//   aria-selected={inRectangle(coord, anchor, focus) ? 'true' : 'false'}
// commit:  Enter or click on another cell applies editing.draft
// cancel:  Escape restores the original value, formula bar shows it
// formula bar: value = editing ? draft : (formulaOf(selected) ?? valueOf(selected))
```

Rules the graders assert verbatim (see your INTERACTION SEMANTICS section):
- Escape cancels an uncommitted edit; Enter commits.
- aria-selected must be maintained on EVERY gridcell, true inside the
  current rectangle, false outside.
- One visible error element per failure, exact message strings from the
  requirement.
- DIALOG CONTRACT: prefer the NATIVE <dialog> element — keep a ref,
  call ref.current.showModal() to open and ref.current.close() to
  dismiss; Escape, backdrop click handling, and focus trapping come
  with the platform for free (never hand-roll an overlay). Every
  dialog closes on Escape AND on cancel/overlay click, and its confirm
  button carries the requirement's EXACT name ("Delete", not "Delete
  worksheet"). An undismissable overlay blocks every later grader
  step; a misnamed confirm is never found.
- SELECTION CONTRACT: Shift-click EXTENDS the selection — the plain
  click handler must not collapse it (guard with e.shiftKey); sort /
  filter / validation / pivot ranges all read the selection anchor, so
  one collapsing handler breaks five requirement families.
- GRID COMPLETENESS: the grid renders its FULL structure — visible
  columnheader cells (column letters) and rowheader cells (row
  numbers) around role="gridcell" cells named by coordinate. A grid
  that renders only the data region fails every structural step.
- DROPDOWN CONTRACT: dropdowns are native <select> with real <option>
  labels (graders use getByRole('combobox') + selectOption). Never a
  custom div dropdown — without full ARIA combobox semantics it is
  invisible to every selector.
- SUBMIT ENABLEMENT: a submit/save button becomes ENABLED once the
  required fields are filled. Disabled is a transient state (Undo with
  an empty stack), never permanent — a permanently disabled submit can
  never be clicked by a test.
- Downloaded/exported files are byte-exact: no UTF-8 BOM, exact CSV
  quoting.

Keep feature files additive: a later requirement EXTENDS the state model
(import it) instead of forking it — the post-batch regression runs every
completed feature's specs against your changes.
