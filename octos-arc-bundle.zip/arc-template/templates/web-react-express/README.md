# Web Template

Single-origin web application: Express serves `/api/*` routes and the built
frontend from `frontend/dist` (SPA fallback), listening on `PORT` plus every
port in `ARC_EXTRA_PORTS`.

- `frontend/`: React + Vite; `npm run build` produces `frontend/dist/`.
- `backend/`: Express; data model is declared in `backend/data/schema.json`
  and compiled by the host into `backend/src/database/schema.js`; JSON store
  at `backend/data/db.json`; auth (register/login/logout/me) and CRUD are
  engine-driven; task-specific endpoints go in `backend/src/routes/index.js`.
- npm dependencies are prewarmed by the host; never run npm install in turns.
