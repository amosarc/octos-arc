"""
frontend 模板常量(纯标准库):React+Vite 模块化八件套。
"""

from __future__ import annotations

FRONTEND_PACKAGE_JSON = {
    "name": "frontend",
    "version": "1.0.0",
    "private": True,
    # ESM 包:src 全部 import/export 语法(jsx/app 库);node 侧单测
    # (csv.js)与 vite 消费同一语义,无双模块系统漂移。
    "type": "module",
    "scripts": {"build": "vite build"},
    "dependencies": {"react": "^18.3.1", "react-dom": "^18.3.1"},
    "devDependencies": {"@vitejs/plugin-react": "^4.3.1", "vite": "^5.2.0"},
}

FRONTEND_INDEX_HTML = """\
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>App</title>
    <script data-host="__arcTelemetryHook">
      // Host-owned frontend error hook (best-effort): page errors and
      // unhandled rejections are beaconed to the backend telemetry endpoint
      // so eval-time crashes land in octos/logs/eval-traffic.jsonl.
      (function () {
        var send = function (kind, msg) {
          try {
            var payload = JSON.stringify({ kind: kind, msg: String(msg).slice(0, 300), href: location.href });
            navigator.sendBeacon('/api/__telemetry', new Blob([payload], { type: 'application/json' }));
          } catch (e) { /* best effort */ }
        };
        window.addEventListener('error', function (e) {
          send('pageerror', (e && e.message ? e.message : 'error') + ' @' + ((e && e.filename) || '') + ':' + ((e && e.lineno) || ''));
        });
        window.addEventListener('unhandledrejection', function (e) {
          send('unhandledrejection', e && e.reason !== undefined ? e.reason : 'rejection');
        });
      })();
    </script>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
"""

FRONTEND_MAIN_JSX = """\
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './app/App.jsx';
import './app/styles.css';

createRoot(document.getElementById('root')).render(<App />);
"""

FRONTEND_APP_JSX = """\
import React from 'react';
import { DataProvider } from './store.jsx';

// ASSEMBLY LAYER — the only file that wires features together: add ONE
// import + mount per requirement family. Business logic lives in
// frontend/src/features/<name>.jsx (self-contained).
export default function App() {
  return (
    <DataProvider>
      <div className="app">
        {/* mount feature components here */}
      </div>
    </DataProvider>
  );
}
"""

FRONTEND_STORE_JSX = """\
import React, {
  createContext, useCallback, useContext, useEffect, useMemo, useState,
} from 'react';
import { api } from './api.js';

// Shared-data layer: load backend resources through
// useResource('<resource>') so shared entities live in one place; features
// read `items` and call create/update/remove.
const DataContext = createContext(null);

export function DataProvider({ children }) {
  const [collections, setCollections] = useState({});

  const ensure = useCallback((resource) => {
    setCollections((prev) => {
      if (prev[resource]) return prev;
      return { ...prev, [resource]: { items: [], ready: false } };
    });
  }, []);

  const refresh = useCallback(async (resource) => {
    ensure(resource);
    try {
      const items = await api.list(resource);
      setCollections((prev) => ({
        ...prev,
        [resource]: { items, ready: true },
      }));
    } catch {
      setCollections((prev) => ({
        ...prev,
        [resource]: { items: prev[resource]?.items || [], ready: true },
      }));
    }
  }, [ensure]);

  const create = useCallback(async (resource, data) => {
    const item = await api.create(resource, data);
    setCollections((prev) => ({
      ...prev,
      [resource]: { items: [...(prev[resource]?.items || []), item], ready: true },
    }));
    return item;
  }, []);

  const update = useCallback(async (resource, id, data) => {
    const item = await api.update(resource, id, data);
    setCollections((prev) => ({
      ...prev,
      [resource]: {
        items: (prev[resource]?.items || []).map((x) => (x.id === id ? item : x)),
        ready: true,
      },
    }));
    return item;
  }, []);

  const remove = useCallback(async (resource, id) => {
    await api.remove(resource, id);
    setCollections((prev) => ({
      ...prev,
      [resource]: {
        items: (prev[resource]?.items || []).filter((x) => x.id !== id),
        ready: true,
      },
    }));
  }, []);

  const value = useMemo(
    () => ({ collections, refresh, create, update, remove }),
    [collections, refresh, create, update, remove],
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useResource(resource) {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useResource must be used inside <DataProvider>');
  const collection = ctx.collections[resource];
  useEffect(() => {
    if (!collection || !collection.ready) ctx.refresh(resource);
  }, [resource]); // eslint-disable-line react-hooks/exhaustive-deps
  return {
    items: collection?.items || [],
    ready: Boolean(collection?.ready),
    refresh: () => ctx.refresh(resource),
    create: (data) => ctx.create(resource, data),
    update: (id, data) => ctx.update(resource, id, data),
    remove: (id) => ctx.remove(resource, id),
  };
}
"""

FRONTEND_API_JS = """\
// Minimal same-origin REST client for the backend API.
// Non-2xx responses throw a structured error: `err.status` is the HTTP
// code and `err.body` is the parsed JSON response (raw text when not
// JSON). Read field errors from `err.body` — never parse `err.message`:
//   catch (err) { setErrors(err.body?.errors ?? []); }
async function request(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    ...options,
  });
  if (!res.ok) {
    const raw = await res.text().catch(() => '');
    let body;
    try { body = JSON.parse(raw); } catch { body = raw; }
    const err = new Error(`${options.method || 'GET'} ${path} -> ${res.status}`);
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return res.status === 204 ? null : res.json();
}

const qs = (params) => {
  if (!params) return '';
  const pairs = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`);
  return pairs.length ? `?${pairs.join('&')}` : '';
};

export const api = {
  list: (resource, params) => request(`/api/${resource}${qs(params)}`),
  get: (resource, id) => request(`/api/${resource}/${id}`),
  create: (resource, data) =>
    request(`/api/${resource}`, { method: 'POST', body: JSON.stringify(data) }),
  update: (resource, id, data) =>
    request(`/api/${resource}/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  patch: (resource, id, data) =>
    request(`/api/${resource}/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  remove: (resource, id) =>
    request(`/api/${resource}/${id}`, { method: 'DELETE' }),
};
"""

FRONTEND_STYLES_CSS = """\
/* Global base styles. Add feature-scoped styles inside each feature file
   (a <style> block or a colocated .css import), not here. */
* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  color: #1f2933;
  background: #f8f9fa;
}
.app { max-width: 960px; margin: 0 auto; padding: 16px; }
.row { display: flex; gap: 8px; align-items: center; }
.column { display: flex; flex-direction: column; gap: 8px; }
.card { background: #fff; border: 1px solid #e0e6eb; border-radius: 8px; padding: 12px; }
.button {
  border: 1px solid #cbd2d9; background: #fff; border-radius: 6px;
  padding: 6px 12px; cursor: pointer; font-size: 14px;
}
.button:hover { background: #f0f4f8; }
.input, .textarea {
  border: 1px solid #cbd2d9; border-radius: 6px;
  padding: 6px 10px; font-size: 14px; font-family: inherit;
}
.muted { color: #616e7c; }
.error-text { color: #c0392b; }
"""

# B2(run-002 复盘):各批次自造网格状态模型、反复重写同一共享文件是
# 回归震荡的根源。宿主以只读 README 给出规范内核模式——选中模型/
# aria 契约/Escape/Enter 语义/公式栏回显——feature 实现一律建立在该
# 模式之上。README 属宿主契约(角色 host),模型禁改。
FEATURES_README = """\
# frontend/src/features — feature implementation notes

Each requirement domain lives in its own self-contained file here
(<name>.jsx, default export). This README is HOST-OWNED (read-only).
Stubs are pre-created per requirement family (REQ ids in the headers) —
fill them in place and add sibling files freely.

## Grid editor kernel pattern (spreadsheet-like tasks)

Import the host-shipped kernel instead of re-deriving selection
semantics:

```jsx
import { useGrid } from '../app/grid.js';

const grid = useGrid({ initial: 'A1', onSelect: persistSelection });
<FixedGrid name="Worksheet grid" grid={grid} rows={30} cols={12}
           textAt={(coord) => displayValue(cells, coord)} />
```

The kernel derives click / SHIFT-click-extend / drag selection and
whole-grid aria-selected; your own onCellClick runs before it (commit a
pending edit there) and onSelect(anchor, focus) persists. Editing goes
through beginEdit/setDraft/commitEdit/cancelEdit (Enter commits, Escape
cancels). Formulas come from ../app/formula.js (displayValue,
evalFormula, adjustFormula, shiftRefs*); interactive primitives
(dialog, dropdown, region, menus, field errors) from ../app/ui.jsx.
Keep feature files additive: a later requirement EXTENDS the state
model instead of forking it.
"""

# UI kit(09-27 契合度定论 S3):满分形态从提示词规则下沉为代码——
# 满分版与平台版两代独立代码、同一坑两跑重现,证明"规则文本靠模型
# 抽样遵守"方差过大;这些原语让正确形态成为默认路径(零新依赖)。
# 09-28 增量(sheet 56 分法医):Region 原语("A region named X" 契约
# 短语的 region role 由 <section> 隐式提供——div aria-label 评测器
# getByRole('region') 0 命中,pivot 全族 10/10 卡死);FixedGrid 集成
# grid.js 内核(Shift-click 扩选/拖选/aria 全网格判定内建,塌缩 onClick
# 规则文本两跑失效后改由代码兜底)+ 表头 aria-label + 编辑态输入 +
# 筛选/验证扩展点(对齐满分版模板演进形态)。
FRONTEND_UI_JSX = """\
import React, { useEffect, useRef } from 'react';
import { inRectangle } from './grid.js';

// UI kit — primitives shaped for Playwright role/label locators (exact
// accessible names, getByLabel, native selects, strict-mode single
// matches). Prefer them over hand-rolled substitutes.

// Dropdown: native <select> (graders call selectOption).
export function NativeSelect({ label, value, onChange, options, id }) {
  const fid = id || 'sel-' + label;
  return (
    <span className="control">
      <label htmlFor={fid}>{label}</label>
      <select id={fid} value={value}
              onChange={(e) => onChange && onChange(e.target.value)}>
        {(options || []).map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </span>
  );
}

// Modal: native <dialog> + showModal() — Escape/backdrop/focus included.
export function AppDialog({ name, open, onClose, children }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (open && !el.open) el.showModal();
    if (!open && el.open) el.close();
  }, [open]);
  return (
    <dialog ref={ref} aria-label={name} onClose={onClose}>{children}</dialog>
  );
}

// Region: requirement phrase "A region named X" => <Region label="X">
// (<section> carries the ARIA region role).
export function Region({ label, children, ...rest }) {
  return (
    <section aria-label={label} {...rest}>{children}</section>
  );
}

// AccountTrigger: renders the signed-in username as its own exact-text
// element; pass `label` (from the requirement) to name the trigger.
export function AccountTrigger({ username, onOpen, label }) {
  const props = label ? { 'aria-label': label } : {};
  return (
    <button {...props} onClick={onOpen}>
      <span className="acc-username">{username}</span>
    </button>
  );
}

// SingleError: exactly ONE error element at a time (strict mode).
export function SingleError({ message }) {
  if (!message) return null;
  return <div role="alert" className="form-error">{message}</div>;
}

// FieldError/byField: per-field errors from the backend
// {errors:[{field,msg}]} shape — all invalid fields show messages together.
export const byField = (errors, field) =>
  (errors || []).filter((e) => e && e.field === field).slice(0, 1);
export function FieldError({ errors, field }) {
  const first = byField(errors, field)[0];
  if (!first) return null;
  return <div role="alert" className="error-text">{first.msg}</div>;
}

// Context menus: role=menu + menuitem buttons labelled verbatim; close
// on Escape and outside click. items: [{label, onSelect}].
export function useContextMenu() {
  const [menu, setMenu] = React.useState(null);
  const open = (e) => { e.preventDefault(); setMenu({ x: e.clientX, y: e.clientY }); };
  const close = () => setMenu(null);
  return { menu, open, close };
}

export function Menu({ menu, onClose, items }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!menu) return;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    const onDown = (e) => {
      if (ref.current && !ref.current.contains(e.target)) onClose();
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onDown);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onDown);
    };
  }, [menu, onClose]);
  if (!menu) return null;
  return (
    <div ref={ref} role="menu" className="ctx-menu"
         style={{ position: 'fixed', left: menu.x, top: menu.y, zIndex: 1000 }}>
      {(items || []).map((it) => (
        <button key={it.label} role="menuitem"
                onClick={() => { onClose(); it.onSelect && it.onSelect(); }}>
          {it.label}
        </button>
      ))}
    </div>
  );
}

// Column letters wrap past Z (AA, AB, ...) — no artificial column cap.
const colLetters = (n) => {
  const out = [];
  for (let i = 0; i < Math.max(1, n); i++) {
    let s = '';
    let j = i;
    do { s = String.fromCharCode(65 + (j % 26)) + s; j = Math.floor(j / 26) - 1; } while (j >= 0);
    out.push(s);
  }
  return out;
};

// FixedGrid: spreadsheet-shaped grid, FIXED SIZE — empty cells beyond the
// data stay selectable; never smaller than 40 rows x 20 cols, sized from
// the seeded/imported extent plus margin. role=grid, columnheaders by
// letter, rowheaders by number, gridcell names = coordinate (A1).
// Pass the useGrid kernel (./grid.js) as `grid`: click/SHIFT-extend/drag
// selection and whole-grid aria-selected come built in; your own on*
// callbacks fire first. headerExtra/cellExtra decorate cells; rowHidden
// filters rows without deleting them.
export function FixedGrid({ name, rows = 40, cols = 20, multiselectable = true,
                            textAt, selected, grid,
                            onCellClick, onCellDown, onCellEnter,
                            onCellDoubleClick, onContextMenu,
                            onColumnHeaderMenu, onRowHeaderMenu,
                            editing, onEditChange, onEditKeyDown,
                            headerExtra, cellExtra, rowHidden }) {
  const letters = colLetters(cols);
  const isSelected = (coord) => (grid
    ? inRectangle(coord, grid.anchor, grid.focus)
    : Boolean(selected && selected.has && selected.has(coord)));
  const editingCell = editing || (grid && grid.editing) || null;
  return (
    <table role="grid" aria-label={name}
           aria-multiselectable={multiselectable ? 'true' : 'false'}>
      <thead>
        <tr role="row">
          <td></td>
          {letters.map((c) => (
            <th key={c} role="columnheader" aria-label={c}
                onContextMenu={(e) => {
                  e.preventDefault();
                  onColumnHeaderMenu && onColumnHeaderMenu(c, e);
                }}>
              {c}
              {headerExtra ? headerExtra(c) : null}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {Array.from({ length: rows }, (_, i) => i + 1).map((r) => (
          <tr key={r} role="row" hidden={rowHidden ? rowHidden(r) : false}>
            <th role="rowheader" aria-label={String(r)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  onRowHeaderMenu && onRowHeaderMenu(r, e);
                }}>
              {String(r)}
            </th>
            {letters.map((c) => {
              const coord = c + r;
              const sel = isSelected(coord);
              const isEditing = editingCell && editingCell.coord === coord;
              return (
                <td key={coord} role="gridcell" aria-label={coord}
                    aria-selected={sel ? 'true' : 'false'}
                    onClick={(e) => {
                      onCellClick && onCellClick(coord, e);
                      grid && grid.handleCellClick(coord, e);
                    }}
                    onMouseDown={(e) => {
                      onCellDown && onCellDown(coord, e);
                      grid && grid.handleCellMouseDown(coord, e);
                    }}
                    onMouseEnter={() => {
                      onCellEnter && onCellEnter(coord);
                      grid && grid.handleCellMouseEnter(coord);
                    }}
                    onDoubleClick={() => onCellDoubleClick && onCellDoubleClick(coord)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      onContextMenu && onContextMenu(coord, e);
                      grid && grid.handleCellClick(coord, e);
                    }}>
                  {isEditing ? (
                    <input className="cell-editor" aria-label={'Edit ' + coord}
                           value={editingCell.draft} autoFocus
                           onChange={(e) => onEditChange && onEditChange(e.target.value)}
                           onKeyDown={(e) => onEditKeyDown && onEditKeyDown(e)} />
                  ) : (
                    <React.Fragment>
                      {textAt ? (textAt(coord) || '') : ''}
                      {cellExtra ? cellExtra(coord) : null}
                    </React.Fragment>
                  )}
                </td>
              );
            })}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
"""
