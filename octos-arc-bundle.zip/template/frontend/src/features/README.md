# frontend/src/features — feature implementation notes

Each requirement domain lives in its own self-contained file here
(<name>.jsx, default export). This README is HOST-OWNED (read-only).
The host PRE-CREATES one stub per requirement family at initialization
(headers list the family's REQ ids as a work order); fill them in place
and add sibling files freely — the division is a starting grid, not a cage.

## Grid editor kernel pattern (spreadsheet-like tasks)

The kernel is HOST-SHIPPED CODE, not a pattern to re-derive. Import it and
the graded interaction semantics hold by construction:

```jsx
// frontend/src/app/grid.js (host-owned): useGrid + geometry helpers
import { useGrid, rectOf, inRectangle, rangeCoords } from '../app/grid.js';

const grid = useGrid({ initial: 'A1', onSelect: persistSelection });
// FixedGrid wires click/SHIFT-click-extend/drag/aria-selected for you:
<FixedGrid name="Worksheet grid" grid={grid} rows={30} cols={12}
           textAt={(coord) => displayValue(cells, coord)} />
```

- aria-selected is derived from anchor/focus for the WHOLE rendered grid —
  never maintain a per-cell Set (a Set capped at the render extent ships
  stale aria state the moment the grid grows).
- Task layer stays yours: in your own onCellClick (runs BEFORE the kernel
  handler) commit a pending edit; persist via onSelect(anchor, focus);
  drive the editing input with beginEdit/setDraft/commitEdit/cancelEdit
  (Enter commits, Escape cancels).
- FORMULAS: import the engine from ../app/formula.js — displayValue(cells,
  coord) for the grid, evalFormula for checks, adjustFormula for
  copy/paste, shiftRefsOnRowChange/shiftRefsOnColChange for row/column
  operations. Do NOT hand-roll an evaluator: hand-rolled ones have shipped
  #ERROR! on =SUM(A1:A3)*2, on spaces (=A1 + B1), on unary minus and on
  nested calls; this engine handles all of them plus the graded error
  vocabulary (#DIV/0!, #REF!, #NAME?, #ERROR!).

Rules the graders assert verbatim (see your INTERACTION SEMANTICS section):
- Escape cancels an uncommitted edit; Enter commits.
- aria-selected must be true on EVERY gridcell inside the current
  rectangle and false outside (the kernel derives this; keep it true when
  you hand-roll a grid instead).
- One visible error element per failure, exact message strings from the
  requirement.
- REGION CONTRACT: a requirement phrase "A region named X" is the ARIA
  region role — render <Region label="X"> (frontend/src/app/ui.jsx) so
  getByRole('region', { name: X }) resolves. A <div aria-label> has NO
  region role and the grader's locator times out (an entire pivot family
  died exactly this way).
- DIALOG CONTRACT: prefer the NATIVE <dialog> element — keep a ref,
  call ref.current.showModal() to open and ref.current.close() to
  dismiss; Escape, backdrop click handling, and focus trapping come
  with the platform for free (never hand-roll an overlay). Every
  dialog closes on Escape AND on cancel/overlay click, and its confirm
  button carries the requirement's EXACT name ("Delete", not "Delete
  worksheet"). An undismissable overlay blocks every later grader
  step; a misnamed confirm is never found.
- SELECTION CONTRACT (built into the useGrid kernel): Shift-click
  EXTENDS the selection and a plain click replaces it — never write a
  click handler that collapses a shift-extend (sort / filter / validation
  / pivot ranges all read the selection anchor, so one collapsing handler
  breaks five requirement families; this exact bug shipped twice).
- GRID SIZING: size FixedGrid from the data you must SHOW plus margin —
  derive rows/cols from the seeded/imported extent (e.g.
  max(26, maxRow + 6) × max(10, maxCol + 4)); a grid smaller than the
  imported data hides rows/columns no test can reach.
- GRID COMPLETENESS: the grid renders its FULL structure — visible
  columnheader cells (column letters) and rowheader cells (row
  numbers) around role="gridcell" cells named by coordinate. A grid
  that renders only the data region fails every structural step.
- DROPDOWN CONTRACT: dropdowns are native <select> with real <option>
  labels (graders use getByRole('combobox') + selectOption). Never a
  custom div dropdown — without full ARIA combobox semantics it is
  invisible to every selector.
- SUBMIT ENABLEMENT: a submit/save button becomes ENABLED once the
  required fields are filled. Disabled is a transient state (Undo with
  an empty stack), never permanent — a permanently disabled submit can
  never be clicked by a test.
- Downloaded/exported files are byte-exact: no UTF-8 BOM, exact CSV
  quoting.

Keep feature files additive: a later requirement EXTENDS the state model
(import it) instead of forking it — the post-batch regression runs every
completed feature's specs against your changes.
