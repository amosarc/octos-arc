# frontend/src/features — feature implementation notes

Each requirement domain lives in its own self-contained file here
(<name>.jsx, default export). This README is HOST-OWNED (read-only).
Stubs are pre-created per requirement family (REQ ids in the headers) —
fill them in place and add sibling files freely.

## Grid editor kernel pattern (spreadsheet-like tasks)

Import the host-shipped kernel instead of re-deriving selection
semantics:

```jsx
import { useGrid } from '../app/grid.js';

const grid = useGrid({ initial: 'A1', onSelect: persistSelection });
<FixedGrid name="Worksheet grid" grid={grid} rows={30} cols={12}
           textAt={(coord) => displayValue(cells, coord)} />
```

The kernel derives click / SHIFT-click-extend / drag selection and
whole-grid aria-selected; your own onCellClick runs before it (commit a
pending edit there) and onSelect(anchor, focus) persists. Editing goes
through beginEdit/setDraft/commitEdit/cancelEdit (Enter commits, Escape
cancels). Formulas come from ../app/formula.js (displayValue,
evalFormula, adjustFormula, shiftRefs*); interactive primitives
(dialog, dropdown, region, menus, field errors) from ../app/ui.jsx.
Keep feature files additive: a later requirement EXTENDS the state
model instead of forking it.
