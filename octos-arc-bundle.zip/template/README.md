# Web Template

Single-origin web application: Express serves `/api/*` routes and the built
frontend from `frontend/dist` (SPA fallback), listening on `PORT` plus every
port in `ARC_EXTRA_PORTS`.

- `frontend/`: React + Vite; `npm run build` produces `frontend/dist/`.
- `backend/`: Express; JSON store at `backend/data/db.json` (the graded
  seed — runtime state goes to `db.run.json`, which resets to the seed on
  every restart and never ships). The host owns only the substrate
  (`src/app.js`, `src/index.js`, `src/lib/util.js`, `src/database/store.js`);
  ALL API endpoints — auth included — are implemented by the agent in
  `backend/src/routes/`.
- npm dependencies are prewarmed by the host; never run npm install in turns.
